﻿namespace CEB_App
{
    partial class frm_genCatGP_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_tile = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnl_input = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_calculate = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tb_units = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pnl_result = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.lbl_4 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.lbl_3 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lbl_2 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lbl_1 = new System.Windows.Forms.Label();
            this.tbl_billRate = new System.Windows.Forms.TableLayoutPanel();
            this.lbl_t_2 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbl_t_4 = new System.Windows.Forms.Label();
            this.lbl_t_3 = new System.Windows.Forms.Label();
            this.lbl_t_1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pnl_tile.SuspendLayout();
            this.pnl_input.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pnl_result.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tbl_billRate.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_tile
            // 
            this.pnl_tile.BackColor = System.Drawing.Color.Black;
            this.pnl_tile.Controls.Add(this.label2);
            this.pnl_tile.Controls.Add(this.label1);
            this.pnl_tile.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_tile.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pnl_tile.Location = new System.Drawing.Point(0, 0);
            this.pnl_tile.Name = "pnl_tile";
            this.pnl_tile.Size = new System.Drawing.Size(800, 95);
            this.pnl_tile.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("Impact", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(0, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(800, 27);
            this.label2.TabIndex = 1;
            this.label2.Text = "Customer Category  GP - 1";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Impact", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(800, 60);
            this.label1.TabIndex = 0;
            this.label1.Text = "GENERAL PURPOSE";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_input
            // 
            this.pnl_input.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(40)))));
            this.pnl_input.Controls.Add(this.panel2);
            this.pnl_input.Controls.Add(this.panel1);
            this.pnl_input.Controls.Add(this.label3);
            this.pnl_input.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_input.Location = new System.Drawing.Point(0, 95);
            this.pnl_input.Name = "pnl_input";
            this.pnl_input.Size = new System.Drawing.Size(800, 68);
            this.pnl_input.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btn_calculate);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(615, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(185, 68);
            this.panel2.TabIndex = 6;
            // 
            // btn_calculate
            // 
            this.btn_calculate.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_calculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calculate.Location = new System.Drawing.Point(16, 6);
            this.btn_calculate.Name = "btn_calculate";
            this.btn_calculate.Size = new System.Drawing.Size(157, 56);
            this.btn_calculate.TabIndex = 0;
            this.btn_calculate.Text = "CALCULATE";
            this.btn_calculate.UseVisualStyleBackColor = true;
            this.btn_calculate.Click += new System.EventHandler(this.btn_calculate_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tb_units);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(334, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(466, 68);
            this.panel1.TabIndex = 5;
            // 
            // tb_units
            // 
            this.tb_units.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_units.Location = new System.Drawing.Point(23, 28);
            this.tb_units.Name = "tb_units";
            this.tb_units.Size = new System.Drawing.Size(86, 20);
            this.tb_units.TabIndex = 3;
            this.tb_units.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Left;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(334, 68);
            this.label3.TabIndex = 2;
            this.label3.Text = "No of Units Consumed in last 30 days";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_result
            // 
            this.pnl_result.Controls.Add(this.tableLayoutPanel1);
            this.pnl_result.Controls.Add(this.tbl_billRate);
            this.pnl_result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_result.Location = new System.Drawing.Point(0, 163);
            this.pnl_result.Name = "pnl_result";
            this.pnl_result.Size = new System.Drawing.Size(800, 433);
            this.pnl_result.TabIndex = 3;
            this.pnl_result.Visible = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 61.60267F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.008348F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.38898F));
            this.tableLayoutPanel1.Controls.Add(this.label27, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label26, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl_4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label25, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label23, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label22, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl_2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label20, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label19, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label18, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 126);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 307);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label27.Location = new System.Drawing.Point(0, 228);
            this.label27.Margin = new System.Windows.Forms.Padding(0);
            this.label27.Name = "label27";
            this.label27.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label27.Size = new System.Drawing.Size(492, 79);
            this.label27.TabIndex = 24;
            this.label27.Text = "Total charge (Rs.)";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label26.Location = new System.Drawing.Point(492, 228);
            this.label26.Margin = new System.Windows.Forms.Padding(0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(40, 79);
            this.label26.TabIndex = 23;
            this.label26.Text = "=";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_4
            // 
            this.lbl_4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.lbl_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_4.Location = new System.Drawing.Point(532, 228);
            this.lbl_4.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_4.Name = "lbl_4";
            this.lbl_4.Size = new System.Drawing.Size(268, 79);
            this.lbl_4.TabIndex = 22;
            this.lbl_4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label25.Location = new System.Drawing.Point(492, 152);
            this.label25.Margin = new System.Windows.Forms.Padding(0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(40, 76);
            this.label25.TabIndex = 21;
            this.label25.Text = "=";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_3
            // 
            this.lbl_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.lbl_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_3.Location = new System.Drawing.Point(532, 152);
            this.lbl_3.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_3.Name = "lbl_3";
            this.lbl_3.Size = new System.Drawing.Size(268, 76);
            this.lbl_3.TabIndex = 20;
            this.lbl_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label23.Location = new System.Drawing.Point(0, 152);
            this.label23.Margin = new System.Windows.Forms.Padding(0);
            this.label23.Name = "label23";
            this.label23.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label23.Size = new System.Drawing.Size(492, 76);
            this.label23.TabIndex = 19;
            this.label23.Text = "Fixed charges (Rs.)";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label22.Location = new System.Drawing.Point(492, 76);
            this.label22.Margin = new System.Windows.Forms.Padding(0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(40, 76);
            this.label22.TabIndex = 18;
            this.label22.Text = "=";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_2
            // 
            this.lbl_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.lbl_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_2.Location = new System.Drawing.Point(532, 76);
            this.lbl_2.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_2.Name = "lbl_2";
            this.lbl_2.Size = new System.Drawing.Size(268, 76);
            this.lbl_2.TabIndex = 17;
            this.lbl_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label20.Location = new System.Drawing.Point(492, 0);
            this.label20.Margin = new System.Windows.Forms.Padding(0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(40, 76);
            this.label20.TabIndex = 16;
            this.label20.Text = "=";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label19.Location = new System.Drawing.Point(0, 0);
            this.label19.Margin = new System.Windows.Forms.Padding(0);
            this.label19.Name = "label19";
            this.label19.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label19.Size = new System.Drawing.Size(492, 76);
            this.label19.TabIndex = 15;
            this.label19.Text = "Charge for first 300 UNITS";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label18.Location = new System.Drawing.Point(0, 76);
            this.label18.Margin = new System.Windows.Forms.Padding(0);
            this.label18.Name = "label18";
            this.label18.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label18.Size = new System.Drawing.Size(492, 76);
            this.label18.TabIndex = 14;
            this.label18.Text = "Charge after 300 UNITS";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_1
            // 
            this.lbl_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.lbl_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_1.Location = new System.Drawing.Point(532, 0);
            this.lbl_1.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_1.Name = "lbl_1";
            this.lbl_1.Size = new System.Drawing.Size(268, 76);
            this.lbl_1.TabIndex = 13;
            this.lbl_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbl_billRate
            // 
            this.tbl_billRate.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl_billRate.ColumnCount = 4;
            this.tbl_billRate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.57143F));
            this.tbl_billRate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.80952F));
            this.tbl_billRate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.80952F));
            this.tbl_billRate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.80952F));
            this.tbl_billRate.Controls.Add(this.lbl_t_2, 1, 2);
            this.tbl_billRate.Controls.Add(this.label12, 0, 2);
            this.tbl_billRate.Controls.Add(this.lbl_t_4, 3, 1);
            this.tbl_billRate.Controls.Add(this.lbl_t_3, 2, 1);
            this.tbl_billRate.Controls.Add(this.lbl_t_1, 1, 1);
            this.tbl_billRate.Controls.Add(this.label8, 0, 1);
            this.tbl_billRate.Controls.Add(this.label7, 3, 0);
            this.tbl_billRate.Controls.Add(this.label6, 2, 0);
            this.tbl_billRate.Controls.Add(this.label5, 1, 0);
            this.tbl_billRate.Controls.Add(this.label4, 0, 0);
            this.tbl_billRate.Dock = System.Windows.Forms.DockStyle.Top;
            this.tbl_billRate.Location = new System.Drawing.Point(0, 0);
            this.tbl_billRate.Name = "tbl_billRate";
            this.tbl_billRate.RowCount = 3;
            this.tbl_billRate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tbl_billRate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tbl_billRate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tbl_billRate.Size = new System.Drawing.Size(800, 126);
            this.tbl_billRate.TabIndex = 0;
            // 
            // lbl_t_2
            // 
            this.lbl_t_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t_2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t_2.Location = new System.Drawing.Point(229, 83);
            this.lbl_t_2.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t_2.Name = "lbl_t_2";
            this.lbl_t_2.Size = new System.Drawing.Size(189, 42);
            this.lbl_t_2.TabIndex = 9;
            this.lbl_t_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label12.Location = new System.Drawing.Point(1, 83);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(227, 42);
            this.label12.TabIndex = 8;
            this.label12.Text = ">300";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t_4
            // 
            this.lbl_t_4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t_4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t_4.Location = new System.Drawing.Point(609, 42);
            this.lbl_t_4.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t_4.Name = "lbl_t_4";
            this.tbl_billRate.SetRowSpan(this.lbl_t_4, 2);
            this.lbl_t_4.Size = new System.Drawing.Size(190, 83);
            this.lbl_t_4.TabIndex = 7;
            this.lbl_t_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t_3
            // 
            this.lbl_t_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t_3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t_3.Location = new System.Drawing.Point(419, 42);
            this.lbl_t_3.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t_3.Name = "lbl_t_3";
            this.tbl_billRate.SetRowSpan(this.lbl_t_3, 2);
            this.lbl_t_3.Size = new System.Drawing.Size(189, 83);
            this.lbl_t_3.TabIndex = 6;
            this.lbl_t_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t_1
            // 
            this.lbl_t_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t_1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t_1.Location = new System.Drawing.Point(229, 42);
            this.lbl_t_1.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t_1.Name = "lbl_t_1";
            this.lbl_t_1.Size = new System.Drawing.Size(189, 40);
            this.lbl_t_1.TabIndex = 5;
            this.lbl_t_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(1, 42);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(227, 40);
            this.label8.TabIndex = 4;
            this.label8.Text = "<301";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Maroon;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(609, 1);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(190, 40);
            this.label7.TabIndex = 3;
            this.label7.Text = "Maximum Demand Charge per Month";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Maroon;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(419, 1);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(189, 40);
            this.label6.TabIndex = 2;
            this.label6.Text = "Fixed Charge";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Maroon;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(229, 1);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(189, 40);
            this.label5.TabIndex = 1;
            this.label5.Text = "Energy Charge (LKR / kWh)";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Maroon;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1, 1);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(227, 40);
            this.label4.TabIndex = 0;
            this.label4.Text = "Consumption per month (kWh)";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frm_genCatGP_1
            // 
            this.AcceptButton = this.btn_calculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.ClientSize = new System.Drawing.Size(800, 596);
            this.Controls.Add(this.pnl_result);
            this.Controls.Add(this.pnl_input);
            this.Controls.Add(this.pnl_tile);
            this.Name = "frm_genCatGP_1";
            this.Text = "frm_genCatGP_1";
            this.Load += new System.EventHandler(this.frm_genCatGP_1_Load);
            this.pnl_tile.ResumeLayout(false);
            this.pnl_input.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnl_result.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tbl_billRate.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_tile;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnl_input;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_calculate;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tb_units;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnl_result;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label lbl_4;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label lbl_3;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lbl_2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lbl_1;
        private System.Windows.Forms.TableLayoutPanel tbl_billRate;
        private System.Windows.Forms.Label lbl_t_2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbl_t_4;
        private System.Windows.Forms.Label lbl_t_3;
        private System.Windows.Forms.Label lbl_t_1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
    }
}