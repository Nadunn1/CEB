﻿namespace CEB_App
{
    partial class frm_domBilrate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_tile = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pnl_result = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label23 = new System.Windows.Forms.Label();
            this.lbl_t2_5 = new System.Windows.Forms.Label();
            this.lbl_t2_10 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lbl_t2_4 = new System.Windows.Forms.Label();
            this.lbl_t2_9 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lbl_t2_3 = new System.Windows.Forms.Label();
            this.lbl_t2_8 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lbl_t2_2 = new System.Windows.Forms.Label();
            this.lbl_t2_7 = new System.Windows.Forms.Label();
            this.lbl_t2_6 = new System.Windows.Forms.Label();
            this.lbl_t2_1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lbl_title2 = new System.Windows.Forms.Label();
            this.tbl_billRate = new System.Windows.Forms.TableLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.lbl_t1_2 = new System.Windows.Forms.Label();
            this.lbl_t1_4 = new System.Windows.Forms.Label();
            this.lbl_t1_3 = new System.Windows.Forms.Label();
            this.lbl_t1_1 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.lbl_title1 = new System.Windows.Forms.Label();
            this.pnl_tile.SuspendLayout();
            this.pnl_result.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tbl_billRate.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_tile
            // 
            this.pnl_tile.BackColor = System.Drawing.Color.Black;
            this.pnl_tile.Controls.Add(this.label1);
            this.pnl_tile.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_tile.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pnl_tile.Location = new System.Drawing.Point(0, 0);
            this.pnl_tile.Name = "pnl_tile";
            this.pnl_tile.Size = new System.Drawing.Size(758, 61);
            this.pnl_tile.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Impact", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(758, 60);
            this.label1.TabIndex = 0;
            this.label1.Text = "DOMESTIC PURPOSE";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_result
            // 
            this.pnl_result.Controls.Add(this.tableLayoutPanel1);
            this.pnl_result.Controls.Add(this.lbl_title2);
            this.pnl_result.Controls.Add(this.tbl_billRate);
            this.pnl_result.Controls.Add(this.lbl_title1);
            this.pnl_result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_result.Location = new System.Drawing.Point(0, 61);
            this.pnl_result.Name = "pnl_result";
            this.pnl_result.Size = new System.Drawing.Size(758, 501);
            this.pnl_result.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.25F));
            this.tableLayoutPanel1.Controls.Add(this.label23, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl_t2_5, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl_t2_10, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label20, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl_t2_4, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl_t2_9, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label17, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl_t2_3, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl_t2_8, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label14, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_t2_2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_t2_7, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_t2_6, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl_t2_1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label6, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label7, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 210);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(758, 291);
            this.tableLayoutPanel1.TabIndex = 7;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label23.Location = new System.Drawing.Point(1, 242);
            this.label23.Margin = new System.Windows.Forms.Padding(0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(282, 48);
            this.label23.TabIndex = 18;
            this.label23.Text = ">180";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_5
            // 
            this.lbl_t2_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t2_5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t2_5.Location = new System.Drawing.Point(284, 242);
            this.lbl_t2_5.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_5.Name = "lbl_t2_5";
            this.lbl_t2_5.Size = new System.Drawing.Size(235, 48);
            this.lbl_t2_5.TabIndex = 17;
            this.lbl_t2_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_10
            // 
            this.lbl_t2_10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t2_10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t2_10.Location = new System.Drawing.Point(520, 242);
            this.lbl_t2_10.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_10.Name = "lbl_t2_10";
            this.lbl_t2_10.Size = new System.Drawing.Size(237, 48);
            this.lbl_t2_10.TabIndex = 16;
            this.lbl_t2_10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label20.Location = new System.Drawing.Point(1, 196);
            this.label20.Margin = new System.Windows.Forms.Padding(0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(282, 45);
            this.label20.TabIndex = 15;
            this.label20.Text = "121 - 180";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_4
            // 
            this.lbl_t2_4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t2_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t2_4.Location = new System.Drawing.Point(284, 196);
            this.lbl_t2_4.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_4.Name = "lbl_t2_4";
            this.lbl_t2_4.Size = new System.Drawing.Size(235, 45);
            this.lbl_t2_4.TabIndex = 14;
            this.lbl_t2_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_9
            // 
            this.lbl_t2_9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t2_9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t2_9.Location = new System.Drawing.Point(520, 196);
            this.lbl_t2_9.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_9.Name = "lbl_t2_9";
            this.lbl_t2_9.Size = new System.Drawing.Size(237, 45);
            this.lbl_t2_9.TabIndex = 13;
            this.lbl_t2_9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label17.Location = new System.Drawing.Point(1, 150);
            this.label17.Margin = new System.Windows.Forms.Padding(0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(282, 45);
            this.label17.TabIndex = 12;
            this.label17.Text = "91 - 120";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_3
            // 
            this.lbl_t2_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t2_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t2_3.Location = new System.Drawing.Point(284, 150);
            this.lbl_t2_3.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_3.Name = "lbl_t2_3";
            this.lbl_t2_3.Size = new System.Drawing.Size(235, 45);
            this.lbl_t2_3.TabIndex = 11;
            this.lbl_t2_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_8
            // 
            this.lbl_t2_8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t2_8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t2_8.Location = new System.Drawing.Point(520, 150);
            this.lbl_t2_8.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_8.Name = "lbl_t2_8";
            this.lbl_t2_8.Size = new System.Drawing.Size(237, 45);
            this.lbl_t2_8.TabIndex = 10;
            this.lbl_t2_8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label14.Location = new System.Drawing.Point(1, 104);
            this.label14.Margin = new System.Windows.Forms.Padding(0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(282, 45);
            this.label14.TabIndex = 9;
            this.label14.Text = "61 - 90";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_2
            // 
            this.lbl_t2_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t2_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t2_2.Location = new System.Drawing.Point(284, 104);
            this.lbl_t2_2.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_2.Name = "lbl_t2_2";
            this.lbl_t2_2.Size = new System.Drawing.Size(235, 45);
            this.lbl_t2_2.TabIndex = 8;
            this.lbl_t2_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_7
            // 
            this.lbl_t2_7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t2_7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t2_7.Location = new System.Drawing.Point(520, 104);
            this.lbl_t2_7.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_7.Name = "lbl_t2_7";
            this.lbl_t2_7.Size = new System.Drawing.Size(237, 45);
            this.lbl_t2_7.TabIndex = 7;
            this.lbl_t2_7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_6
            // 
            this.lbl_t2_6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t2_6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t2_6.Location = new System.Drawing.Point(520, 58);
            this.lbl_t2_6.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_6.Name = "lbl_t2_6";
            this.lbl_t2_6.Size = new System.Drawing.Size(237, 45);
            this.lbl_t2_6.TabIndex = 6;
            this.lbl_t2_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_1
            // 
            this.lbl_t2_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t2_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t2_1.Location = new System.Drawing.Point(284, 58);
            this.lbl_t2_1.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_1.Name = "lbl_t2_1";
            this.lbl_t2_1.Size = new System.Drawing.Size(235, 45);
            this.lbl_t2_1.TabIndex = 5;
            this.lbl_t2_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(1, 58);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(282, 45);
            this.label5.TabIndex = 4;
            this.label5.Text = "0 - 60";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Maroon;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(520, 1);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(237, 56);
            this.label6.TabIndex = 2;
            this.label6.Text = "Fixed Charge (LKR/Month)";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Maroon;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(284, 1);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(235, 56);
            this.label7.TabIndex = 1;
            this.label7.Text = "Energy Charge (LKR / kWh)";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Maroon;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1, 1);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(282, 56);
            this.label8.TabIndex = 0;
            this.label8.Text = "Consumption per month (kWh)";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_title2
            // 
            this.lbl_title2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_title2.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_title2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_title2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_title2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_title2.Location = new System.Drawing.Point(0, 148);
            this.lbl_title2.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_title2.Name = "lbl_title2";
            this.lbl_title2.Size = new System.Drawing.Size(758, 62);
            this.lbl_title2.TabIndex = 6;
            this.lbl_title2.Text = "If the consumption is over 60 kWh per month";
            this.lbl_title2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbl_billRate
            // 
            this.tbl_billRate.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl_billRate.ColumnCount = 3;
            this.tbl_billRate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tbl_billRate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tbl_billRate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tbl_billRate.Controls.Add(this.label11, 0, 2);
            this.tbl_billRate.Controls.Add(this.lbl_t1_2, 0, 2);
            this.tbl_billRate.Controls.Add(this.lbl_t1_4, 0, 2);
            this.tbl_billRate.Controls.Add(this.lbl_t1_3, 2, 1);
            this.tbl_billRate.Controls.Add(this.lbl_t1_1, 1, 1);
            this.tbl_billRate.Controls.Add(this.label35, 0, 1);
            this.tbl_billRate.Controls.Add(this.label37, 2, 0);
            this.tbl_billRate.Controls.Add(this.label38, 1, 0);
            this.tbl_billRate.Controls.Add(this.label39, 0, 0);
            this.tbl_billRate.Dock = System.Windows.Forms.DockStyle.Top;
            this.tbl_billRate.Location = new System.Drawing.Point(0, 62);
            this.tbl_billRate.Name = "tbl_billRate";
            this.tbl_billRate.RowCount = 3;
            this.tbl_billRate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tbl_billRate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tbl_billRate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tbl_billRate.Size = new System.Drawing.Size(758, 86);
            this.tbl_billRate.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.Location = new System.Drawing.Point(1, 57);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(251, 28);
            this.label11.TabIndex = 9;
            this.label11.Text = "31 - 60";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t1_2
            // 
            this.lbl_t1_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t1_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t1_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t1_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t1_2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t1_2.Location = new System.Drawing.Point(253, 57);
            this.lbl_t1_2.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t1_2.Name = "lbl_t1_2";
            this.lbl_t1_2.Size = new System.Drawing.Size(251, 28);
            this.lbl_t1_2.TabIndex = 8;
            this.lbl_t1_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t1_4
            // 
            this.lbl_t1_4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t1_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t1_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t1_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t1_4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t1_4.Location = new System.Drawing.Point(505, 57);
            this.lbl_t1_4.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t1_4.Name = "lbl_t1_4";
            this.lbl_t1_4.Size = new System.Drawing.Size(252, 28);
            this.lbl_t1_4.TabIndex = 7;
            this.lbl_t1_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t1_3
            // 
            this.lbl_t1_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t1_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t1_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t1_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t1_3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t1_3.Location = new System.Drawing.Point(505, 29);
            this.lbl_t1_3.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t1_3.Name = "lbl_t1_3";
            this.lbl_t1_3.Size = new System.Drawing.Size(252, 27);
            this.lbl_t1_3.TabIndex = 6;
            this.lbl_t1_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t1_1
            // 
            this.lbl_t1_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t1_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t1_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t1_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t1_1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t1_1.Location = new System.Drawing.Point(253, 29);
            this.lbl_t1_1.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t1_1.Name = "lbl_t1_1";
            this.lbl_t1_1.Size = new System.Drawing.Size(251, 27);
            this.lbl_t1_1.TabIndex = 5;
            this.lbl_t1_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label35.Location = new System.Drawing.Point(1, 29);
            this.label35.Margin = new System.Windows.Forms.Padding(0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(251, 27);
            this.label35.TabIndex = 4;
            this.label35.Text = "0 - 30";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.Maroon;
            this.label37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(505, 1);
            this.label37.Margin = new System.Windows.Forms.Padding(0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(252, 27);
            this.label37.TabIndex = 2;
            this.label37.Text = "Fixed Charge";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.Maroon;
            this.label38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(253, 1);
            this.label38.Margin = new System.Windows.Forms.Padding(0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(251, 27);
            this.label38.TabIndex = 1;
            this.label38.Text = "Energy Charge (LKR / kWh)";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.Color.Maroon;
            this.label39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(1, 1);
            this.label39.Margin = new System.Windows.Forms.Padding(0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(251, 27);
            this.label39.TabIndex = 0;
            this.label39.Text = "Consumption per month (kWh)";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_title1
            // 
            this.lbl_title1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_title1.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_title1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_title1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_title1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_title1.Location = new System.Drawing.Point(0, 0);
            this.lbl_title1.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_title1.Name = "lbl_title1";
            this.lbl_title1.Size = new System.Drawing.Size(758, 62);
            this.lbl_title1.TabIndex = 5;
            this.lbl_title1.Text = "If the Consumption is between 0 - 60 kWh per month";
            this.lbl_title1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frm_domBilrate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(758, 562);
            this.Controls.Add(this.pnl_result);
            this.Controls.Add(this.pnl_tile);
            this.Name = "frm_domBilrate";
            this.Text = " ";
            this.Load += new System.EventHandler(this.frm_domBilrate_Load);
            this.pnl_tile.ResumeLayout(false);
            this.pnl_result.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tbl_billRate.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_tile;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnl_result;
        private System.Windows.Forms.TableLayoutPanel tbl_billRate;
        private System.Windows.Forms.Label lbl_t1_3;
        private System.Windows.Forms.Label lbl_t1_1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label lbl_title1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lbl_t2_6;
        private System.Windows.Forms.Label lbl_t2_1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbl_title2;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lbl_t2_5;
        private System.Windows.Forms.Label lbl_t2_10;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lbl_t2_4;
        private System.Windows.Forms.Label lbl_t2_9;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lbl_t2_3;
        private System.Windows.Forms.Label lbl_t2_8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lbl_t2_2;
        private System.Windows.Forms.Label lbl_t2_7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lbl_t1_2;
        private System.Windows.Forms.Label lbl_t1_4;
    }
}