﻿namespace CEB_App
{
    partial class frm_govCatGv_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_tile = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnl_input = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_calculate = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tb_units = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pnl_result = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label25 = new System.Windows.Forms.Label();
            this.lbl_3 = new System.Windows.Forms.Label();
            this.lbl_2 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lbl_1 = new System.Windows.Forms.Label();
            this.tbl_billRate = new System.Windows.Forms.TableLayoutPanel();
            this.lbl_t_3 = new System.Windows.Forms.Label();
            this.lbl_t_2 = new System.Windows.Forms.Label();
            this.lbl_t_1 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.pnl_tile.SuspendLayout();
            this.pnl_input.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pnl_result.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tbl_billRate.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_tile
            // 
            this.pnl_tile.BackColor = System.Drawing.Color.Black;
            this.pnl_tile.Controls.Add(this.label2);
            this.pnl_tile.Controls.Add(this.label1);
            this.pnl_tile.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_tile.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pnl_tile.Location = new System.Drawing.Point(0, 0);
            this.pnl_tile.Name = "pnl_tile";
            this.pnl_tile.Size = new System.Drawing.Size(778, 95);
            this.pnl_tile.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("Impact", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(0, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(778, 27);
            this.label2.TabIndex = 1;
            this.label2.Text = "Customer Category  GV - 1";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Impact", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(778, 60);
            this.label1.TabIndex = 0;
            this.label1.Text = "GOVERNMENT PURPOSE";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_input
            // 
            this.pnl_input.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(40)))));
            this.pnl_input.Controls.Add(this.panel2);
            this.pnl_input.Controls.Add(this.panel1);
            this.pnl_input.Controls.Add(this.label3);
            this.pnl_input.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_input.Location = new System.Drawing.Point(0, 95);
            this.pnl_input.Name = "pnl_input";
            this.pnl_input.Size = new System.Drawing.Size(778, 68);
            this.pnl_input.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btn_calculate);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(593, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(185, 68);
            this.panel2.TabIndex = 6;
            // 
            // btn_calculate
            // 
            this.btn_calculate.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_calculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calculate.Location = new System.Drawing.Point(16, 6);
            this.btn_calculate.Name = "btn_calculate";
            this.btn_calculate.Size = new System.Drawing.Size(157, 56);
            this.btn_calculate.TabIndex = 0;
            this.btn_calculate.Text = "CALCULATE";
            this.btn_calculate.UseVisualStyleBackColor = true;
            this.btn_calculate.Click += new System.EventHandler(this.btn_calculate_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tb_units);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(334, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(444, 68);
            this.panel1.TabIndex = 5;
            // 
            // tb_units
            // 
            this.tb_units.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_units.Location = new System.Drawing.Point(6, 28);
            this.tb_units.Name = "tb_units";
            this.tb_units.Size = new System.Drawing.Size(232, 20);
            this.tb_units.TabIndex = 3;
            this.tb_units.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Left;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(334, 68);
            this.label3.TabIndex = 2;
            this.label3.Text = "No of Units Consumed in last 30 days";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_result
            // 
            this.pnl_result.Controls.Add(this.tableLayoutPanel1);
            this.pnl_result.Controls.Add(this.tbl_billRate);
            this.pnl_result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_result.Location = new System.Drawing.Point(0, 163);
            this.pnl_result.Name = "pnl_result";
            this.pnl_result.Size = new System.Drawing.Size(778, 457);
            this.pnl_result.TabIndex = 7;
            this.pnl_result.Visible = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 61.60267F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.008348F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.38898F));
            this.tableLayoutPanel1.Controls.Add(this.label25, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label22, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label21, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label20, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label19, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label18, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 126);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(778, 331);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label25.Location = new System.Drawing.Point(479, 220);
            this.label25.Margin = new System.Windows.Forms.Padding(0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(38, 111);
            this.label25.TabIndex = 21;
            this.label25.Text = "=";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_3
            // 
            this.lbl_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.lbl_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_3.Location = new System.Drawing.Point(517, 220);
            this.lbl_3.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_3.Name = "lbl_3";
            this.lbl_3.Size = new System.Drawing.Size(261, 111);
            this.lbl_3.TabIndex = 20;
            this.lbl_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_2
            // 
            this.lbl_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.lbl_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_2.Location = new System.Drawing.Point(517, 110);
            this.lbl_2.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_2.Name = "lbl_2";
            this.lbl_2.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_2.Size = new System.Drawing.Size(261, 110);
            this.lbl_2.TabIndex = 19;
            this.lbl_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label22.Location = new System.Drawing.Point(0, 220);
            this.label22.Margin = new System.Windows.Forms.Padding(0);
            this.label22.Name = "label22";
            this.label22.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label22.Size = new System.Drawing.Size(479, 111);
            this.label22.TabIndex = 18;
            this.label22.Text = "Total Charges (Rs.)";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label21.Location = new System.Drawing.Point(479, 110);
            this.label21.Margin = new System.Windows.Forms.Padding(0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(38, 110);
            this.label21.TabIndex = 17;
            this.label21.Text = "=";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label20.Location = new System.Drawing.Point(479, 0);
            this.label20.Margin = new System.Windows.Forms.Padding(0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(38, 110);
            this.label20.TabIndex = 16;
            this.label20.Text = "=";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label19.Location = new System.Drawing.Point(0, 0);
            this.label19.Margin = new System.Windows.Forms.Padding(0);
            this.label19.Name = "label19";
            this.label19.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label19.Size = new System.Drawing.Size(479, 110);
            this.label19.TabIndex = 15;
            this.label19.Text = "Charge for UNITS (Rs.)";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label18.Location = new System.Drawing.Point(0, 110);
            this.label18.Margin = new System.Windows.Forms.Padding(0);
            this.label18.Name = "label18";
            this.label18.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label18.Size = new System.Drawing.Size(479, 110);
            this.label18.TabIndex = 14;
            this.label18.Text = "Fixed Charge (Rs.)";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_1
            // 
            this.lbl_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.lbl_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_1.Location = new System.Drawing.Point(517, 0);
            this.lbl_1.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_1.Name = "lbl_1";
            this.lbl_1.Size = new System.Drawing.Size(261, 110);
            this.lbl_1.TabIndex = 13;
            this.lbl_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbl_billRate
            // 
            this.tbl_billRate.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tbl_billRate.ColumnCount = 3;
            this.tbl_billRate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.5F));
            this.tbl_billRate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.25F));
            this.tbl_billRate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.25F));
            this.tbl_billRate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tbl_billRate.Controls.Add(this.lbl_t_3, 2, 1);
            this.tbl_billRate.Controls.Add(this.lbl_t_2, 1, 1);
            this.tbl_billRate.Controls.Add(this.lbl_t_1, 0, 1);
            this.tbl_billRate.Controls.Add(this.label37, 2, 0);
            this.tbl_billRate.Controls.Add(this.label38, 1, 0);
            this.tbl_billRate.Controls.Add(this.label39, 0, 0);
            this.tbl_billRate.Dock = System.Windows.Forms.DockStyle.Top;
            this.tbl_billRate.Location = new System.Drawing.Point(0, 0);
            this.tbl_billRate.Name = "tbl_billRate";
            this.tbl_billRate.RowCount = 2;
            this.tbl_billRate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl_billRate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbl_billRate.Size = new System.Drawing.Size(778, 126);
            this.tbl_billRate.TabIndex = 0;
            // 
            // lbl_t_3
            // 
            this.lbl_t_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t_3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t_3.Location = new System.Drawing.Point(534, 63);
            this.lbl_t_3.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t_3.Name = "lbl_t_3";
            this.lbl_t_3.Size = new System.Drawing.Size(243, 62);
            this.lbl_t_3.TabIndex = 6;
            this.lbl_t_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t_2
            // 
            this.lbl_t_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t_2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t_2.Location = new System.Drawing.Point(292, 63);
            this.lbl_t_2.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t_2.Name = "lbl_t_2";
            this.lbl_t_2.Size = new System.Drawing.Size(241, 62);
            this.lbl_t_2.TabIndex = 5;
            this.lbl_t_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t_1
            // 
            this.lbl_t_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.lbl_t_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t_1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_t_1.Location = new System.Drawing.Point(1, 63);
            this.lbl_t_1.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t_1.Name = "lbl_t_1";
            this.lbl_t_1.Size = new System.Drawing.Size(290, 62);
            this.lbl_t_1.TabIndex = 4;
            this.lbl_t_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.Maroon;
            this.label37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(534, 1);
            this.label37.Margin = new System.Windows.Forms.Padding(0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(243, 61);
            this.label37.TabIndex = 2;
            this.label37.Text = "Fixed Charge";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.Maroon;
            this.label38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(292, 1);
            this.label38.Margin = new System.Windows.Forms.Padding(0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(241, 61);
            this.label38.TabIndex = 1;
            this.label38.Text = "Energy Charge (LKR / kWh)";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.Color.Maroon;
            this.label39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(1, 1);
            this.label39.Margin = new System.Windows.Forms.Padding(0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(290, 61);
            this.label39.TabIndex = 0;
            this.label39.Text = "Consumption per month (kWh)";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frm_govCatGv_1
            // 
            this.AcceptButton = this.btn_calculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.ClientSize = new System.Drawing.Size(778, 620);
            this.Controls.Add(this.pnl_result);
            this.Controls.Add(this.pnl_input);
            this.Controls.Add(this.pnl_tile);
            this.Name = "frm_govCatGv_1";
            this.Text = "frm_govCatGv_1";
            this.Load += new System.EventHandler(this.frm_govCatGv_1_Load);
            this.pnl_tile.ResumeLayout(false);
            this.pnl_input.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnl_result.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tbl_billRate.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_tile;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnl_input;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_calculate;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tb_units;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnl_result;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label lbl_3;
        private System.Windows.Forms.Label lbl_2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lbl_1;
        private System.Windows.Forms.TableLayoutPanel tbl_billRate;
        private System.Windows.Forms.Label lbl_t_3;
        private System.Windows.Forms.Label lbl_t_2;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label lbl_t_1;
        private System.Windows.Forms.Label label39;
    }
}